import * as React from 'react';
import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';
import BlurLinearIcon from '@mui/icons-material/BlurLinear';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import PlaylistAddCheckIcon from '@mui/icons-material/PlaylistAddCheck';
import Toolbar from '@mui/material/Toolbar';
import { makeStyles } from '@mui/styles';
import PluginContainer from '../components/plugin/PluginsContainer';
import SideBar from '../components/sideBar/SideBar';
import { Routes, Route, useLocation } from 'react-router-dom';
import mockJson from '../mockData.json'
import { Get } from '../services/fetch';

const drawerWidth = 400;

const useStyles = makeStyles((theme) => ({
    headerName: {
        flexGrow: 1,
        textAlign: "center",
        margin: "auto",
        padding: "20px"
    },
    boldHeaderName: {
        fontWeight: "800"
    },
    mainContainer: {
        paddingLeft: '20px'
    }
}));

const menuItems = [
    { name: 'Marketing', icon: <BlurLinearIcon />, route: "/marketing" },
    { name: 'Finance', icon: <MonetizationOnIcon />, route: "/finance" },
    { name: 'Personnel', icon: <PlaylistAddCheckIcon />, route: "/personal" }
]

const routTabMap = {
    "/marketing": "tab1",
    "/finance": "tab2",
    "/personal": "tab3"
}

// const { tabdata, plugins } = mockJson;

function Home(props) {


    const [tabsData, setTabsData] = React.useState({})
    const [plugins, setPlugins] = React.useState({})

    const [pluginDisabled, setPluginDisabled] = React.useState(false)


    const classes = useStyles();
    const [mobileOpen, setMobileOpen] = React.useState(false);

    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen);
    };

    const handleAllSelect = (event) => {
        setPluginDisabled(!event.target.checked);

    }

    React.useEffect(() => {
        const fetchAllData = async () => {
            const [tabs, plugins] = await Promise.all([
                Get('/tabs'),
                Get('/plugins'),
            ]);
            const tabsDataMap = Object.fromEntries(tabs.map(tab => [tab.name, tab]))
            const pluginsDataMap = Object.fromEntries(plugins.map(plugin => [plugin.name, plugin]))
            setTabsData(tabsDataMap)
            setPlugins(pluginsDataMap)
        }
        fetchAllData()
    }, [])

    const commonProps = { handleDrawerToggle, tabdata: tabsData, plugins, pluginDisabled }
    return (
        <Box sx={{ display: 'flex' }} className={classes.mainContainer}>
            <CssBaseline />
            <SideBar {...{ onAllSelect: handleAllSelect, handleDrawerToggle, menuItems, mobileOpen, drawerWidth, ...props }}></SideBar>
            <Box
                component="main"
                sx={{ flexGrow: 1, p: 3, width: { sm: `calc(100% - ${drawerWidth}px)` } }}
            >
                <Toolbar />

                <Routes>
                    <Route path="/" element={<PluginContainer {...commonProps} title='Marketing Plugins' name="tab1" />} />
                    <Route path="marketing" element={<PluginContainer {...commonProps} title='Marketing Plugins' name="tab1" />} />
                    <Route path="finance" element={<PluginContainer {...commonProps} title='Finance Plugins' name="tab2" />} />
                    <Route path="personal" element={<PluginContainer {...commonProps} title='Personal Plugins' name="tab3" />} />
                </Routes>

            </Box>
        </Box>
    );
}

Home.propTypes = {
    window: PropTypes.func,
};

export default Home;
