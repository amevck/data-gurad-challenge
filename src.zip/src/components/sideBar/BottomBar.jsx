import React from 'react';
import PropTypes from 'prop-types';
import { AppBar, Grid, Typography } from '@mui/material';
import { Box } from '@mui/system';
import Switch from '../styled/Switch';
import { makeStyles } from '@mui/styles';


const useStyles = makeStyles((theme) => ({

    appBarTypography: {
        color: 'black',

    },
    appBar: {
        background: 'rgba(255,255,255,0.5) !important',
        backdropFilter: 'blur(5px) !important'
    }

}));

const DrowerBottomBar = props => {
    const classes = useStyles();
    return (
        <AppBar elevation={0}
            className={classes.appBar} position="absolute" color="primary" sx={{ top: 'auto', bottom: 10 }}>
            <Grid container  >
                <Grid item xs={8} >
                    <Box sx={{ pl: 4 }}>
                        <Typography variant="h6" noWrap component="div" className={classes.appBarTypography}>
                            {'All plugin enabled'}
                        </Typography>
                    </Box>
                </Grid>
                <Grid item xs={4} >
                    <Box display="flex" >
                        <Switch onChange={props.onAllSelect} defaultChecked={true} > </Switch>
                    </Box>
                </Grid>

            </Grid>
        </AppBar>
    );
};

DrowerBottomBar.propTypes = {

};

export default DrowerBottomBar;